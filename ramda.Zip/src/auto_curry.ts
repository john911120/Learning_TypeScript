import * as R from 'ramda';

console.log(
    R.add(700, 3),
    R.add(700)(4)
);