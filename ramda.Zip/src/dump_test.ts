import * as R from 'ramda';
//import { dump } from './dump';
import { dump } from './dump2';

//dump(R.range(1,51));
dump(R.range(1, 21));