import * as R from 'ramda';
console.log(R.range(1, 9 + 1));