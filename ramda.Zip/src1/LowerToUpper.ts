import * as R from 'ramda';

console.log(R.toUpper('hello world'),R.toLower('HELLO WORLD'));