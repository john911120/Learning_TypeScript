import * as R from 'ramda';

console.log(R.trim('  hello world  '));