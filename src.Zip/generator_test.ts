import { generator } from "./generator";
for(let value of generator())
    console.log(value);