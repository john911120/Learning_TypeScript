import { StringIterable } from './StringIterable';
for(let value of new StringIterable(['Hello', 'World', 'TypeScript']))
    console.log(value);