import { createRangeIterable } from "./createRangeIterable";

const iterable = createRangeIterable(1, 5);
/*
for(let value of iterable)
    console.log(value);
 
*/