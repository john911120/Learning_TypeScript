import { generator12345 } from "./yield_star";

for(let value of generator12345()) {
    console.log(value);
}