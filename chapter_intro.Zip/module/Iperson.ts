export default interface NormalHuman {
    name : string
    age : number
}