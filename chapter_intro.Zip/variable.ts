var a = 1911;
var b = 'pistol';

console.log(a + ' ' + b);